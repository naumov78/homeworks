# w4d5: [Reddit On Rails][description]

* Now with model testing!
* [Live Demo](http://aa-reddit.herokuapp.com)

[description]: https://github.com/appacademy/rails-curriculum/blob/master/projects/w4d5-reddit-clone.md
