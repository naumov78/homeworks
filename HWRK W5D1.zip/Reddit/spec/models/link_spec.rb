require 'spec_helper'

describe Link do

  it { should validate_presence_of(:url) }
  it { should validate_presence_of(:title) }
  it { should validate_presence_of(:user) }

  it { should have_many(:link_subs) }
  it { should have_many(:subs).through(:link_subs) }
  it { should have_many(:user_votes) }
  it { should have_many(:comments) }
  it { should belong_to(:user) }

  it "associates with the correct link before save via inverse_of" do
    user = FactoryGirl.build(:user)
    link = user.links.new
    expect(link.user).to be(user)
  end

  describe "#comments_by_parent" do

    def build_comment(link, moderator, parent_comment = nil)
      comment = link.comments.new
      comment.parent_comment = parent_comment
      comment.user = moderator
      comment.body = "Anything"
      comment.save
      comment
    end

  end
end
