# class SessionsController < ApplicationController
#
#     def create
#         user = User.find_by_credentials(params[:user][:username], params[:user][:password])
#
#         if user.nil?
#             render json: "Credentials were wrong"
#         else
#             render json: "Welcome back #{ user.username }"
#         end
#     end
#
#
#     # def create_session_token
#     #
#     # end
#     #
#     # def ensure_session_token
#     #
#     # end
#     #
#     # def reset_session_token
#     #
#     # end
#
# end
