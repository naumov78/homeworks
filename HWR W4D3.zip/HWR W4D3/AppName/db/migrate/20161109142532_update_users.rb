class UpdateUsers < ActiveRecord::Migration
  def change
    add_index :users, :userame, unique: true
    add_index :users, :session_token, unique: true
  end


end
