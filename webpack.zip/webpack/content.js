module.exports = "It works from content.js.";
